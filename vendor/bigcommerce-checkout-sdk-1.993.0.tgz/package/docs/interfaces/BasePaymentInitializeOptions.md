[**@bigcommerce/checkout-sdk**](../README.md)

***

[@bigcommerce/checkout-sdk](../README.md) / BasePaymentInitializeOptions

# Interface: BasePaymentInitializeOptions

A set of options that are required to initialize the payment step of the
current checkout flow.

## Extends

- [`PaymentRequestOptions`](PaymentRequestOptions.md)

## Properties

### creditCard?

> `optional` **creditCard?**: `CreditCardPaymentInitializeOptions`

**`Alpha`**

Please note that this option is currently in an early stage of
development. Therefore the API is unstable and not ready for public
consumption.

***

### gatewayId?

> `optional` **gatewayId?**: `string`

The identifier of the payment provider providing the payment method. This
option is only required if the provider offers multiple payment options.
i.e.: Adyen and Klarna.

#### Inherited from

[`PaymentRequestOptions`](PaymentRequestOptions.md).[`gatewayId`](PaymentRequestOptions.md#gatewayid)

***

### integrations?

> `optional` **integrations?**: `PaymentStrategyFactory`\<`PaymentStrategy`\>[]

**`Alpha`**

***

### methodId

> **methodId**: `string`

The identifier of the payment method.

#### Inherited from

[`PaymentRequestOptions`](PaymentRequestOptions.md).[`methodId`](PaymentRequestOptions.md#methodid)

***

### params?

> `optional` **params?**: `object`

The parameters of the request, if required.

#### Inherited from

[`PaymentRequestOptions`](PaymentRequestOptions.md).[`params`](PaymentRequestOptions.md#params)

***

### timeout?

> `optional` **timeout?**: `Timeout`

Provide this option if you want to cancel or time out the request. If the
timeout object completes before the request, the request will be
cancelled.

#### Inherited from

[`PaymentRequestOptions`](PaymentRequestOptions.md).[`timeout`](PaymentRequestOptions.md#timeout)

***

### version?

> `optional` **version?**: `number`

The version of the checkout, used for optimistic concurrency control.

#### Inherited from

[`PaymentRequestOptions`](PaymentRequestOptions.md).[`version`](PaymentRequestOptions.md#version)
