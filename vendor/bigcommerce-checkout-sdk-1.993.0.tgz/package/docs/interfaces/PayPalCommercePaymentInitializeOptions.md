[**@bigcommerce/checkout-sdk**](../README.md)

***

[@bigcommerce/checkout-sdk](../README.md) / PayPalCommercePaymentInitializeOptions

# Interface: PayPalCommercePaymentInitializeOptions

A set of options that are required to initialize the PayPal Commerce payment
method for presenting its PayPal button.

Please note that the minimum version of checkout-sdk is 1.100

Also, PayPal (also known as PayPal Commerce Platform) requires specific options to initialize the PayPal Smart Payment Button on checkout page that substitutes a standard submit button
```html
<!-- This is where the PayPal button will be inserted -->
<div id="container"></div>
```

```js
service.initializePayment({
    methodId: 'paypalcommerce',
    paypalcommerce: {
        container: '#container',
// Callback for submitting payment form that gets called when a buyer approves PayPal payment
        submitForm: () => {
        // Example function
            this.submitOrder(
               {
                  payment: { methodId: 'paypalcommerce', }
              }
           );
        },
// Callback is used to define the state of the payment form, validate if it is applicable for submit.
        onValidate: (resolve, reject) => {
        // Example function
            const isValid = this.validatePaymentForm();
            if (isValid) {
                return resolve();
            }
            return reject();
        },
// Callback that is called right before render of a Smart Payment Button. It gets called when a buyer is eligible for use of the particular PayPal method. This callback can be used to hide the standard submit button.
        onRenderButton: () => {
        // Example function
            this.hidePaymentSubmitButton();
        }
    },
});
```

## Properties

### bannerContainerId?

> `optional` **bannerContainerId?**: `string`

The location to insert the Pay Later Messages.

***

### container?

> `optional` **container?**: `string`

The CSS selector of a container where the payment widget should be inserted into.

***

### shouldRenderPayPalButtonOnInitialization?

> `optional` **shouldRenderPayPalButtonOnInitialization?**: `boolean`

If there is no need to initialize the Smart Payment Button, simply pass false as the option value.
The default value is true

## Methods

### getFieldsValues()?

> `optional` **getFieldsValues**(): `HostedInstrument`

A callback for getting form fields values.

#### Returns

`HostedInstrument`

***

### onError()?

> `optional` **onError**(`error`): `void`

A callback for displaying error popup. This callback requires error object as parameter.

#### Parameters

##### error

`unknown`

#### Returns

`void`

***

### onInit()?

> `optional` **onInit**(`callback`): `void`

A callback that gets called when strategy is in the process of initialization before rendering Smart Payment Button.

#### Parameters

##### callback

() => `void`

A function, that calls the method to render the Smart Payment Button.

#### Returns

`void`

***

### onRenderButton()?

> `optional` **onRenderButton**(): `void`

A callback right before render Smart Payment Button that gets called when
Smart Payment Button is eligible. This callback can be used to hide the standard submit button.

#### Returns

`void`

***

### onValidate()?

> `optional` **onValidate**(`resolve`, `reject`): `Promise`\<`void`\>

A callback that gets called when a buyer click on Smart Payment Button
and should validate payment form.

#### Parameters

##### resolve

() => `void`

A function, that gets called if form is valid.

##### reject

() => `void`

A function, that gets called if form is not valid.

#### Returns

`Promise`\<`void`\>

reject() or resolve()

***

### submitForm()?

> `optional` **submitForm**(): `void`

A callback for submitting payment form that gets called
when buyer approved PayPal account.

#### Returns

`void`
