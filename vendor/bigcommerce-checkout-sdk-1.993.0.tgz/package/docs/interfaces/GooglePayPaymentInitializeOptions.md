[**@bigcommerce/checkout-sdk**](../README.md)

***

[@bigcommerce/checkout-sdk](../README.md) / GooglePayPaymentInitializeOptions

# Interface: GooglePayPaymentInitializeOptions

A set of options that are required to initialize the GooglePay payment method

If the customer chooses to pay with GooglePay, they will be asked to
enter their payment details via a modal. You can hook into events emitted by
the modal by providing the callbacks listed below.

```html
<!-- This is where the GooglePay button will be inserted -->
<div id="wallet-button"></div>
```

```js
service.initializePayment({
    // Using GooglePay provided by Braintree as an example
    methodId: 'googlepaybraintree',
    googlepaybraintree: {
        walletButton: 'wallet-button'
    },
});
```

Additional event callbacks can be registered.

```js
service.initializePayment({
    methodId: 'googlepaybraintree',
    googlepaybraintree: {
        walletButton: 'wallet-button',
        onError(error) {
            console.log(error);
        },
        onPaymentSelect() {
            console.log('Selected');
        },
    },
});
```

Alternatively, a container-based Google Pay button can be rendered directly
in the payment step (replacing the Place Order button):

```js
service.initializePayment({
    methodId: 'googlepaybraintree',
    googlepaybraintree: {
        container: 'checkout-payment-continue',
        onInit(renderButton) {
            // Hide Place Order, then render the button once container is in DOM
            renderButton();
        },
        onError(error) {
            console.log(error);
        },
    },
});
```

## Properties

### buttonColor?

> `optional` **buttonColor?**: [`GooglePayButtonColor`](../type-aliases/GooglePayButtonColor.md)

The color of the Google Pay button rendered into `container`.
Defaults to `'default'`.

***

### buttonSizeMode?

> `optional` **buttonSizeMode?**: [`GooglePayButtonSizeMode`](../type-aliases/GooglePayButtonSizeMode.md)

The size mode of the Google Pay button rendered into `container`.
Defaults to `'fill'`.

***

### buttonType?

> `optional` **buttonType?**: [`GooglePayButtonType`](../type-aliases/GooglePayButtonType.md)

The type/label of the Google Pay button rendered into `container`.
Defaults to `'pay'`.

***

### container?

> `optional` **container?**: `string`

The ID of the container element where the Google Pay button will be rendered.
When provided, a branded Google Pay button is created inside this container.
Clicking the button opens the Google Pay payment sheet and, on success, submits
the order and redirects to the order confirmation page directly — no separate
"Place Order" step is needed.

***

### loadingContainerId?

> `optional` **loadingContainerId?**: `string`

A container for loading spinner.

***

### walletButton?

> `optional` **walletButton?**: `string`

This walletButton is used to set an event listener, provide an element ID if you want
users to be able to launch the GooglePay wallet modal by clicking on a button.
It should be an HTML element.

## Methods

### getFieldsValues()?

> `optional` **getFieldsValues**(): `HostedInstrument`

A callback that returns the shopper's stored-instrument choices from the
checkout form. It is invoked when the shopper pays, not when the strategy
is initialized, so it always reflects the current state of the
"save payment method" checkbox.

#### Returns

`HostedInstrument`

***

### onError()?

> `optional` **onError**(`error`): `void`

A callback that gets called when GooglePay fails to initialize or
selects a payment option.

#### Parameters

##### error

`Error`

The error object describing the failure.

#### Returns

`void`

***

### onInit()?

> `optional` **onInit**(`renderButton`): `void`

Called after the Google Pay processor is fully initialized, with a
`renderButton` function that — when invoked — creates the Google Pay
button inside `container`.  Use this callback to control timing: hide
the Place Order button first, then call `renderButton()` once the
container element is present in the DOM.

Only used when `container` is provided.

#### Parameters

##### renderButton

() => `void`

#### Returns

`void`

***

### onPaymentSelect()?

> `optional` **onPaymentSelect**(): `void`

A callback that gets called when the customer selects a payment option.

#### Returns

`void`
