[**@bigcommerce/checkout-sdk**](../README.md)

***

[@bigcommerce/checkout-sdk](../README.md) / CheckoutSettings

# Interface: CheckoutSettings

## Properties

### capabilities?

> `optional` **capabilities?**: [`Capabilities`](Capabilities.md)

***

### checkoutBillingSameAsShippingEnabled

> **checkoutBillingSameAsShippingEnabled**: `boolean`

***

### checkoutUserExperienceSettings

> **checkoutUserExperienceSettings**: [`UserExperienceSettings`](UserExperienceSettings.md)

***

### enableOrderComments

> **enableOrderComments**: `boolean`

***

### enableTermsAndConditions

> **enableTermsAndConditions**: `boolean`

***

### features

> **features**: `Record`\<`string`, `boolean`\>

***

### googleMapsApiKey

> **googleMapsApiKey**: `string`

***

### googleRecaptchaSitekey

> **googleRecaptchaSitekey**: `string`

***

### guestCheckoutEnabled

> **guestCheckoutEnabled**: `boolean`

***

### hasMultiShippingEnabled

> **hasMultiShippingEnabled**: `boolean`

***

### isAccountCreationEnabled

> **isAccountCreationEnabled**: `boolean`

***

### isAnalyticsEnabled

> **isAnalyticsEnabled**: `boolean`

***

### isCardVaultingEnabled

> **isCardVaultingEnabled**: `boolean`

***

### isCouponCodeCollapsed

> **isCouponCodeCollapsed**: `boolean`

***

### isCustomCheckout?

> `optional` **isCustomCheckout?**: `boolean`

***

### isExpressPrivacyPolicy

> **isExpressPrivacyPolicy**: `boolean`

***

### isPaymentRequestCanMakePaymentEnabled

> **isPaymentRequestCanMakePaymentEnabled**: `boolean`

***

### isPaymentRequestEnabled

> **isPaymentRequestEnabled**: `boolean`

***

### isPhoneNumberValidationEnabled?

> `optional` **isPhoneNumberValidationEnabled?**: `boolean`

***

### isSignInEmailEnabled

> **isSignInEmailEnabled**: `boolean`

***

### isSpamProtectionEnabled

> **isSpamProtectionEnabled**: `boolean`

***

### isStorefrontSpamProtectionEnabled

> **isStorefrontSpamProtectionEnabled**: `boolean`

***

### isTrustedShippingAddressEnabled

> **isTrustedShippingAddressEnabled**: `boolean`

***

### orderTermsAndConditions

> **orderTermsAndConditions**: `string`

***

### orderTermsAndConditionsLink

> **orderTermsAndConditionsLink**: `string`

***

### orderTermsAndConditionsLocation

> **orderTermsAndConditionsLocation**: `string`

***

### orderTermsAndConditionsType

> **orderTermsAndConditionsType**: `string`

***

### privacyPolicyUrl

> **privacyPolicyUrl**: `string`

***

### providerWithCustomCheckout

> **providerWithCustomCheckout**: `string` \| `null`

***

### realtimeShippingProviders

> **realtimeShippingProviders**: `string`[]

***

### remoteCheckoutProviders

> **remoteCheckoutProviders**: `any`[]

***

### requiresMarketingConsent

> **requiresMarketingConsent**: `boolean`

***

### shippingQuoteFailedMessage

> **shippingQuoteFailedMessage**: `string`

***

### shouldRedirectToStorefrontForAuth

> **shouldRedirectToStorefrontForAuth**: `boolean`
