[**@bigcommerce/checkout-sdk**](../README.md)

***

[@bigcommerce/checkout-sdk](../README.md) / CustomerRequestOptions

# Interface: CustomerRequestOptions

A set of options for configuring any requests related to the customer step of
the current checkout flow.

Some payment methods have their own sign-in or sign-out flow. Therefore, you
need to indicate the method you want to use if you need to trigger a specific
flow for signing in or out a customer. Otherwise, these options are not required.

## Extends

- [`RequestOptions`](RequestOptions.md)

## Extended by

- [`BaseCustomerInitializeOptions`](BaseCustomerInitializeOptions.md)
- [`ExecutePaymentMethodCheckoutOptions`](ExecutePaymentMethodCheckoutOptions.md)

## Properties

### methodId?

> `optional` **methodId?**: `string`

***

### params?

> `optional` **params?**: `object`

The parameters of the request, if required.

#### Inherited from

[`RequestOptions`](RequestOptions.md).[`params`](RequestOptions.md#params)

***

### timeout?

> `optional` **timeout?**: `Timeout`

Provide this option if you want to cancel or time out the request. If the
timeout object completes before the request, the request will be
cancelled.

#### Inherited from

[`RequestOptions`](RequestOptions.md).[`timeout`](RequestOptions.md#timeout)

***

### version?

> `optional` **version?**: `number`

The version of the checkout, used for optimistic concurrency control.

#### Inherited from

[`RequestOptions`](RequestOptions.md).[`version`](RequestOptions.md#version)
