[**@bigcommerce/checkout-sdk**](../README.md)

***

[@bigcommerce/checkout-sdk](../README.md) / OrderRequestBody

# Interface: OrderRequestBody

An object that contains the information required for submitting an order.

## Properties

### additionalText?

> `optional` **additionalText?**: `string`

***

### orderExtraFields?

> `optional` **orderExtraFields?**: [`OrderExtraFieldValue`](OrderExtraFieldValue.md)[]

***

### payment?

> `optional` **payment?**: [`OrderPaymentRequestBody`](OrderPaymentRequestBody.md)

An object that contains the payment details of a customer. In some cases,
you can omit this object if the order does not require further payment.
For example, the customer is able to use their store credit to pay for
the entire order. Or they have already submitted their payment details
using PayPal.

***

### poNumber?

> `optional` **poNumber?**: `string`

***

### useStoreCredit?

> `optional` **useStoreCredit?**: `boolean`

If true, apply the store credit of the customer to the order. It only
works if the customer has previously signed in.
